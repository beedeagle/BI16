USE [AdventureWorksDW2016];
GO

DROP PROCEDURE [dbo].[uspReport_OrganizationExpenditures];
GO
