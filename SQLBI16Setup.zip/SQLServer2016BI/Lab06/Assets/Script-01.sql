USE [MDS];
GO

--Retrieve MDS and SQL Server index metadata
SELECT
	[e].[Name] AS [MDS_EntityName]
	,[e].[EntityTable] AS [MDS_EntityTable]
	,[idx].[Name] AS [MDS_IndexName]
	,[sidx].[name] AS [SQL_IndexName]
	,[sidx].[type_desc] AS [SQL_IndexType]
	,[sidx].[is_unique] AS [SQL_IndexIsUnique]
	,[sidx].[filter_definition] AS [SQL_IndexFilterDefinition]
FROM
	[mdm].[tblEntity] AS [e]
	INNER JOIN [mdm].[tblIndex] AS [idx]
		ON [idx].[Entity_ID] = [e].[ID]
	INNER JOIN [sys].[indexes] AS [sidx]
		ON [sidx].[index_id] = [idx].[SysIndex_ID]
WHERE
	[e].[Name] = N'City';
