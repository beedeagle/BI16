PRINT N'Remove user-defined objects created in the MDS database';
GO
DROP PROCEDURE [usr].[SetIpAddressLocator];
DROP FUNCTION [usr].[ConvertIntegerToIpAddress];
DROP SEQUENCE [usr].[IpAddress];
DROP FUNCTION [usr].[IsTextValueEmpty];
GO
