USE [AdventureWorksDW2016];
GO

DROP PROCEDURE [dbo].[uspKpi_ResellerSales];
DROP PROCEDURE [dbo].[uspKpi_ResellerSales_Trend];
GO
