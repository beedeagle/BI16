USE [AdventureWorksDW2016];
GO

DROP TABLE [etl].[PackageExecutionLog];
DROP TABLE [etl].[CountrySales_LoadErrors];
DROP TABLE [etl].[CountrySales];
GO

DROP SCHEMA [etl];
GO
