CREATE PROCEDURE [dbo].[uspReport_OrganizationExpenditures]
	@OrganizationKey INT
	,@DateFrom DATE
	,@DateTo DATE
	,@DepartmentGroupKey INT
AS
	SET NOCOUNT ON;

	WITH [Accounts] AS
	(
		SELECT
			[a1].[AccountDescription] AS [Level_01]
			,[a2].[AccountDescription] AS [Level_02]
			,[a3].[AccountDescription] AS [Level_03]
			,COALESCE([a3].[AccountKey], [a2].[AccountKey], [a1].[AccountKey]) AS [AccountKey]
			,ROW_NUMBER() OVER (PARTITION BY COALESCE([a3].[AccountKey], [a2].[AccountKey], [a1].[AccountKey]) ORDER BY [a3].[AccountKey] DESC, [a2].[AccountKey] DESC) AS [RowNumber]
		FROM
			[dbo].[DimAccount] AS [a1]
			LEFT JOIN [dbo].[DimAccount] AS [a2] ON [a2].[ParentAccountKey] = [a1].[AccountKey]
			LEFT JOIN [dbo].[DimAccount] AS [a3] ON [a3].[ParentAccountKey] = [a2].[AccountKey]
		WHERE
			[a1].[AccountType] = N'Expenditures'
	)
	SELECT
		[a].[Level_01]
		,[a].[Level_02]
		,[a].[Level_03]
		,CAST(SUM([f].[Amount]) AS MONEY) AS [Amount]
	FROM
		[Accounts] AS [a]
		INNER JOIN [dbo].[FactFinance] AS [f] ON [f].[AccountKey] = [a].[AccountKey]
	WHERE
		[a].[RowNumber] = 1
		AND [f].[ScenarioKey] = 1
		AND [f].[OrganizationKey] = @OrganizationKey
		AND [f].[Date] BETWEEN @DateFrom AND @DateTo
		AND [f].[DepartmentGroupKey] = CASE WHEN @DepartmentGroupKey = -1 THEN [f].[DepartmentGroupKey] ELSE @DepartmentGroupKey END
	GROUP BY
		[a].[Level_01]
		,[a].[Level_02]
		,[a].[Level_03];
GO